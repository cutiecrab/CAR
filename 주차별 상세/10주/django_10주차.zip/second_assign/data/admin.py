from django.contrib import admin
from .models import CorFeatures, Corporates
# Register your models here.


admin.site.register(CorFeatures)
admin.site.register(Corporates)
